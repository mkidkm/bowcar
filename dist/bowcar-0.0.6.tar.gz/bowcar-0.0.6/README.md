바우카를 이용하여 파이썬을 배우기 위한 모듈입니다.
this module for study python with bowcar hardware.

arduino-cli 프로그램의 설치가 필수입니다.
this module need 'arduino-cli' program.