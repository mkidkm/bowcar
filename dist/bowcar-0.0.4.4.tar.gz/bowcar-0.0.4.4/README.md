바우카를 이용하여 파이썬을 배우기 위한 모듈입니다.
this module for study python with bowcar hardware.